from django.http import HttpResponse
from .models import Album
def index(request):
    return HttpResponse("<h1>This is our Homepage<h1>")
def detail(request, Album_id):
    return HttpResponse("<h2>Details of album id : "+ str(Album_id) +"</h2>")
