from django.contrib import admin

from .models import Album
admin.site.register(Album)

from .models import Songs
admin.site.register(Songs)
